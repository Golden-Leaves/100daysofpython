class Post:
    def __init__(self,title,subtitle,body,id):
      self.title = title
      self.subtitle = subtitle
      self.id = id
      self.body = body
    def post(self):
      pass